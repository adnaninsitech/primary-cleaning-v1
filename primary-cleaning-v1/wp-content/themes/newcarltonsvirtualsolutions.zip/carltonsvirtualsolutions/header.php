<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *

 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>


<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>" />
  <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>

  <title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
  <link href="<?php bloginfo('template_directory'); ?>/images/favicon.png" rel="shortcut icon" type="image/x-icon" />
  <link rel="profile" href="http://gmpg.org/xfn/11" />
  <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />


  <!-- Google Fonts -->

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">



  <!-- owl carousel -->
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/slick.css" />
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/slick-theme.css" />
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/camera.css" />
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/prettyPhoto.css" />

  <!-- Font Awesome -->
  <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/fonts/font-awesome/css/font-awesome.css" />


  <?php
  /* We add some JavaScript to pages with the comment form
   * to support sites with threaded comments (when in use).
   */
  if ( is_singular() && get_option( 'thread_comments' ) )
    wp_enqueue_script( 'comment-reply' );
  global $options;global $logo;global $copyrite;
  $options = get_option('cOptn');
  $logo = $options['logo'];
  $copyrite = $options['copyrite'];
  $size = 300;
  $options['logo'] = wp_get_attachment_image($logo, array($size, $size), false);
  $att_img = wp_get_attachment_image($logo, array($size, $size), false); 
  $logoSrc = wp_get_attachment_url($logo);
  $att_src_thumb = wp_get_attachment_image_src($logo, array($size, $size), false);

  /* Always have wp_head() just before the closing </head>
   * tag of your theme, or you will break many plugins, which
   * generally use this hook to add elements to <head> such
   * as styles, scripts, and meta tags.
   */
  wp_head();
  
  
  global $more;
  $more = 0;
  ?>
</head>

<body <?php body_class( $class ); ?>> 

<header>
  <section class="top-header">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="social">
            <a href="<?php echo $options['facebook']  ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="<?php echo $options['twitter']  ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="<?php echo $options['linkedin']  ?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-6">
              <span>Have any question?<a href="tel:<?php echo $options['phone_number']  ?>">Call Us Now!</a></span>
            </div>
            <div class="col-md-6">
              <form action="/" method="get" class="sear-form">
                <input type="text" name="s" id="search" placeholder="Search Here..." required />
                <input type="image" alt="Search" src="<?php bloginfo( 'template_url' ); ?>/images/search.png" />
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="main-head">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <a href="<?php echo site_url(); ?>" class="res" ><?php echo $options['logo']  ?></a>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="box">
            <div class="col-md-6">
              <div class="row">
                <div class="col-md-2"><img src="<?php bloginfo( 'template_url' ); ?>/images/phone.png"></div>
                <div class="col-md-10">
                  <div class="cont">
                  <a href="tel:<?php echo $options['phone_number']  ?>"><?php echo $options['phone_number']  ?></a>
                  <h6><a href="mailto:<?php echo $options['email']  ?>"><?php echo $options['email']  ?></a></h6>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <a href="<?php echo get_site_url(); ?>/contact-us/" id="app-btn">Make an appointment</a>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <nav>
              <?php wp_nav_menu(array('menu'=>'Menu 1')); ?> 
            </nav>
        </div>
      </div> 
    </div>
  </section>
</header>



<?php if(Is_home()|| is_front_page() ) { ?>

  <section class="slide slider-area slider-one clearfix" data-wow-duration="2s" id="home">
    <div  class="slider" id="mainslider">

      <?php $index_query = new WP_Query(array( 'post_type' => 'slider' , 'posts_per_page' => '-1' , 'order' => 'asc'   )); ?>

      <?php while ($index_query->have_posts()) : $index_query->the_post(); ?>


        <div  data-src="<?php the_post_thumbnail_url('full'); ?>">

          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="slide-cont ">
                  <div class=" content">
                    <?php wpautop(the_content()); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>

      <?php endwhile; wp_reset_query(); ?>

    </div>

  </section>

<?php } else { ?>

 <?php  $page = basename(get_permalink()); ?>
<?php $content = get_posts(array('name' => '"'.$page.'"','post_type' => 'page')); ?>
<?php $title =  get_field('banner_title', get_the_ID()); ?>
<?php $image =  get_field('image', get_the_ID()); ?>
<?php if( !empty($image) ){ ?>
<section class="banner" style="background-image: url(<?php echo $image['url']; ?>);">
<?php }else { ?>
<section class="banner">
 <?php } ?>
   <div class="container">
    <div class="row">
      <div class="box">
        <div class="content">
            <div class="col-md-12">
            <?php if($title != ''){ ?>
            <h2><?php echo $title; ?></h2>
          <?php }else{ ?> 
            <h2><?php the_title(); ?></h2>
          <?php } ?>
            
            </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php } ?>
 

        

 <div class="main-wrapper">