<?php
/**
 * The sidebar widget areas.
 */
?>

<div class="sidebar-left">
<h2>Categories</h2>



asdadsasd

<div class="clear"></div>
</div>
