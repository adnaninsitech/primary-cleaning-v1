<?php
/**
 * Template Name: About Template
 */

get_header(); ?>
</div>


<section class="inner-content about-content">
  <div class="wrapper">
  
  <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
            <?php the_content(); ?>
        <?php endwhile; wp_reset_query(); ?>
  </div>
</section>
<section class="content-center video-section">
  <div class="wrapper">
  
  
<?php $index_query = new WP_Query(array( 'post_type' => 'post', 'p' => '52' , 'posts_per_page' => '1')); ?>
    <?php while ($index_query->have_posts()) : $index_query->the_post(); ?>
    <h1><?php the_title(); ?></h1>
      <div class="video"><?php the_content(); ?></div>
    <?php endwhile; wp_reset_query(); ?>
  
   
  
  </div>
</section>





<div class="main-wrapper">
<?php get_footer(); ?>