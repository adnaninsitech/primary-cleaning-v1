<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content
 * after.  Calls sidebar-footer.php for bottom widgets.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

  $options = get_option('cOptn');
 ?>

</div>

<footer>
	
	<section class="footer-top">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<h2>Have any question or need any assistance?</h2>
				</div>
				<div class="col-md-4">
					<a href="<?php echo get_site_url(); ?>/contact-us/">Contact Us Now!!</a>
				</div>
			</div>
		</div>
	</section>
	<section class="main-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<p><?php echo $options['tagline']  ?></p>
					<h2>Newsletter</h2>
					<?php dynamic_sidebar('sidebar-2');  ?>
				</div>
				<div class="col-md-2">
					<h3>Quick Links</h3>
					<?php wp_nav_menu(array('menu'=>'Quick Links')); ?> 
				</div>
				<div class="col-md-3">
					<h3>Our Services</h3>
					<?php wp_nav_menu(array('menu'=>'Our Services')); ?>
				</div>
				<div class="col-md-3">
					<h3>Our Address</h3>
					<div class="cont">
						<a href="javascript:;"><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo $options['Address']  ?></a>
						<a href="tel:<?php echo $options['phone_number']  ?>"><i class="fa fa-phone" aria-hidden="true"></i><?php echo $options['phone_number']  ?></a>
						<a href="mailto:<?php echo $options['email']  ?>"><i class="fa fa-envelope" aria-hidden="true"></i><?php echo $options['email']  ?></a>
						<a href="javascript:;"><i class="fa fa-clock-o" aria-hidden="true"></i><?php echo $options['timing']  ?></a>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="copy">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<p><?php echo $options['copyright']  ?></p>
				</div>
				<div class="col-md-6 text-right">
					 <div class="social">
            <a href="<?php echo $options['facebook']  ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="<?php echo $options['twitter']  ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="<?php echo $options['linkedin']  ?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
          </div>
				</div>
			</div>
		</div>
	</section>


</footer>

<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery-latest.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/slick.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.easing.1.3.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/camera.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/prettyPhoto.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/functions.js"></script>
</body></html>

<?php wp_footer(); ?>

